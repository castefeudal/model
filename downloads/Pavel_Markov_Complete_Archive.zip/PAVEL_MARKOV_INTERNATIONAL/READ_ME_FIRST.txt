PAVEL MARKOV / INTERNATIONAL PRESS KIT
Documents are available in RU, EN and ZH in three complete language folders.
The six authentic personal-archive photographs are stored once in SHARED_PHOTOGRAPHS to avoid duplication.
Archived images are not recent agency casting digitals. Commercial reuse requires separate permission.
